package com.cobranza.gestionclientesmicroservicios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionclientesmicroserviciosApplicationTests {

	@Test
	void contextLoads() {
	}

}
