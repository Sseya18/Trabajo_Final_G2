package com.cobranza.gestionclientesmicroservicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionclientesmicroserviciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionclientesmicroserviciosApplication.class, args);
	}

}
