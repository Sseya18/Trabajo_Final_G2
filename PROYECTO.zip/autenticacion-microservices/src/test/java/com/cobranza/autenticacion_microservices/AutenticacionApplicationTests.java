package com.cobranza.autenticacion_microservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
