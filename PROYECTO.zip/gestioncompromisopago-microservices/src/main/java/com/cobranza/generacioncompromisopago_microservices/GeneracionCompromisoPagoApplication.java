package com.cobranza.generacioncompromisopago_microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeneracionCompromisoPagoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeneracionCompromisoPagoApplication.class, args);
	}

}
