package com.cobranza.generacioncompromisopago_microservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneracionCompromisoPagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
