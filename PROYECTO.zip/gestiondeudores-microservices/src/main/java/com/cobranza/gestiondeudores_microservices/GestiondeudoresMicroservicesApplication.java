package com.cobranza.gestiondeudores_microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestiondeudoresMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestiondeudoresMicroservicesApplication.class, args);
	}

}
