package com.cobranza.gestiondeudores_microservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestiondeudoresMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
